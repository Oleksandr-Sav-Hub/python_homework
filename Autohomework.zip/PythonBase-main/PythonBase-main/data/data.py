class BaseData:
    baseLogin = "guest"
    basePassword = "welcome2qauto"
    host = "qauto.forstudy.space"